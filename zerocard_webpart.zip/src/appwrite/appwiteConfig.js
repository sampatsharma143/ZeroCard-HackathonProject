import { Appwrite } from "appwrite";

const sdk = new Appwrite();

sdk
    .setEndpoint('https://superapp.megamind.app/v1') // Your API Endpoint
    .setProject('62ad9d00262b2158da33') // Your project ID
;

export const db = sdk.database;
export const account =sdk.account;

 export const COLLECTION_ID = 'id_business_cards';