import React, { useState, useEffect } from "react";
import { useHistory } from "react-router";
// import{useSearchParams} from 'react-router-dom';
import { COLLECTION_ID, db } from "../appwrite/appwiteConfig";

const Table = () => {
  const [documents, setDocuments] = useState({});

  const history = useHistory();

  // const [searchParams,setSearchParams] =useSearchParams();
  // const docid = searchParams.get('id')
  //Get all documents
  const getDocuments = async () => {
    const res = await db.getDocument(COLLECTION_ID, '4837294837aaa');
    setDocuments(res);
    console.log(res)
  };
  useEffect(() => {
    getDocuments();
  }, documents);


  return (
  
    <div className="container">
      <header className="App-header">
        <nva className="nav">ZeroCard</nva>
      </header>
    <div className="media mt-5">
      <img src="https://superapp.megamind.app/v1/storage/buckets/62ae81c5a2c73c50b966/files/62ae81e755273026e9e2/view?project=62ad9d00262b2158da33" className="m-3" alt="image" width="75px" height="75px"/>
      <div className="media-body m-2">
        <h5 className="align-items-center mt-2">{documents.business_name}</h5>
        <p>Founder :{documents.business_owner}</p>
        <p>Address :{documents.business_address}</p>

      </div>
    </div>
      <div className="mt-4">


              

                <div>
                <a href={"mailto:"+documents.business_email} class="btn btn-outline-dark btn-block" role="button" target="_blank"><i class="fab fa-envelope-square">&nbsp;</i>{documents.business_email}</a>
                <a href={"tel:"+documents.phone_number} class="btn btn-outline-dark btn-block" role="button" target="_blank"><i class="fab fa-phone">&nbsp;</i>{"Call-"+documents.phone_number}</a>
                
      

                <a href={documents.instagram_link} class="btn btn-outline-dark btn-block" role="button" target="_blank"><i class="fab fa-instagram">&nbsp;</i>Instagram</a>
                <a href={documents.youtube_link} class="btn btn-outline-dark btn-block" role="button" target="_blank"><i class="fab fa-youtube">&nbsp;</i>Youtube</a>
                <a href={documents.business_url} class="btn btn-outline-dark btn-block" role="button" target="_blank"><i class="fa fa-code">&nbsp;</i>Company Site</a>
                  </div>
            
           
            </div>
</div>
  );
};

export default Table;
